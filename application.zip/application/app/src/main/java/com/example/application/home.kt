package com.example.application

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
//import androidx.lifecycle.viewmodel.CreationExtras.Empty.map

class home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)
        var mapbtn=findViewById<Button>(R.id.map_btn)
        var profilebtn=findViewById<Button>(R.id.profile_btn)
        mapbtn.setOnClickListener {
            val intent= Intent(this,map::class.java)
            startActivity(intent)
        }
        profilebtn.setOnClickListener {
            val intent= Intent(this,profile::class.java)
            startActivity(intent)
        }
    }
}