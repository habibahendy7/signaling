package com.example.application

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth

class signup : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_signup)
        auth = FirebaseAuth.getInstance()
        var edtName=findViewById<EditText>(R.id.name)
        var edtEmail=findViewById<EditText>(R.id.email)
        var edtPassword=findViewById<EditText>(R.id.passward)
        var signupbtn=findViewById<Button>(R.id.signup_btn)

        signupbtn.setOnClickListener {
            val email=edtEmail.text.toString()
            val password=edtPassword.text.toString()
            signUp(email,password)
        }
    }

    private fun signUp(email:String,password:String){
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    val intent= Intent(this@signup,home::class.java)
                    startActivity(intent)
                } else {
                    // If sign in fails, display a message to the user.
                    Toast.makeText(this@signup, "Authentication failed.", Toast.LENGTH_SHORT).show()
                }
            }
    }

}