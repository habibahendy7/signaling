package com.example.application

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class profile : AppCompatActivity() {
    private lateinit var editTextBio: EditText
    private lateinit var editButton: Button
    private lateinit var saveButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_profile)

        editTextBio = findViewById(R.id.bio)
        editButton = findViewById(R.id.edit_btn)
        saveButton = findViewById(R.id.save_btn)

        val sharedPreferences = getSharedPreferences("UserProfile", Context.MODE_PRIVATE)
        val savedBio = sharedPreferences.getString("bio", "")
        editTextBio.setText(savedBio)

        editButton.setOnClickListener{
            editTextBio.isEnabled = true
            editTextBio.requestFocus()
        }

        saveButton.setOnClickListener {
            editTextBio.isEnabled = false
            val bioText = editTextBio.text.toString()
            val editor = sharedPreferences.edit()
            editor.putString("bio", bioText)
            editor.apply()
        }

    }
}